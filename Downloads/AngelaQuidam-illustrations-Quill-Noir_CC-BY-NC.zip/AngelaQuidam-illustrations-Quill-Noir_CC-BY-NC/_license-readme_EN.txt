Inside this file you will find illustrations (JPG format, black and white)
created for the French translation of the Quill: Noir supplement
writen by Tim Snider (https://savageafterworld.blogspot.com). 
� French version december 2019, by angela quidam for the association La Caravelle (https://fr.tipeee.com/la-caravelle)


Illustrations are made with Chinese ink and fine point pen.
The illustrations of the characters are based on film noir actors and actresses 
and public domain pictures.

-----------------------------------
LICENSE: CREATIVE COMMONS BY-NC
-----------------------------------
You can use these images for any non-commercial project, the only condition is to credit me.
You are allowed to crop, rotate, color, flip, reduce, enlarge, or otherwise modify these images 
as needed, but if any of the images are resized, the original proportions must be maintained.

For any commercial use or if you have any questions or wish to contact me directly, 
feel free to contact me on itch.io or twitter.

If you're using some, I'd be glad to see your project :)
Please don't use my illustrations for projects promulgating discriminatory statements. Thanks.

Have a nice day!

angela quidam

-----------------------------------
angela-quidam.itch.io
artstation.com/angela-quidam
instagram.com/angela_quidam/
@QuidamAngela

https://wheretofind.me/@angela